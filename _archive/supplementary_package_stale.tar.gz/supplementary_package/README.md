# SilentMethyl supplementary data package

Package status: **COMPLETE**

This package contains the complete tabular evidence and provenance records
needed to inspect the SilentMethyl manuscript. Genomic coordinates are hg38
unless a file explicitly states otherwise.

## Contents

- **Supplementary Data S1 — Candidates:** the 440-candidate ranking, per-seed
  scores, stability tables, sequence-versus-fusion comparison, and the rank-1
  case-study source table.
- **Supplementary Data S2 — mQTL positive control:** the 81-association cohort,
  cross-seed aggregates, clustered metrics, probe-footprint sensitivity, and
  leave-one-variant-out results.
- **Supplementary Data S3 — mQTL matched negative:** the final 35 matched pairs,
  matching balance, cross-seed aggregates, and discrimination statistics.
- **Supplementary Data S4 — model performance:** per-seed held-out metrics,
  paired genomic-block bootstrap differences, and biological-context source
  tables for the manuscript and supplementary figures.
- **Supplementary Data S5 — target QC:** HM450 mask audit and coverage
  sensitivity summaries.
- **Supplementary Data S6 — reproducibility:** construction manifests, audits,
  environment information, and SHA-256 manifests.
- **Supplementary Figures:** only the two manuscript-aligned panels that are
  not main-text figures (`information_source_gains` and
  `fusion_gain_by_genomic_region`). Exploratory plot directories and known-variant
  application figures are excluded.

## Interpretation boundaries

- eGTEx slopes are aligned to increasing VCF ALT dosage. The positive control
  supports signed allelic direction and rank, not direct slope-scale calibration.
- The conservative 53-association subset excludes variants within the annotated
  HM450 probe footprint expanded by one base on either side.
- Matched-background candidate quantities are descriptive comparisons among
  observed synonymous candidates, not calibrated null p-values.
- Nonsignificant mQTL leads are matched comparators, not confirmed causal nulls.
- Candidate outputs are variant-hypothesis rankings and are not experimental or
  causal effect estimates.

## Rebuilding

From the project root, after scripts 02--10 and 12--14 have completed:

```bash
python -u scripts/11_build_supplement_package.py
```

Use `--replace` to rebuild while preserving the prior package in a timestamped
backup. `supplement_manifest.csv` maps every packaged file to its source and
description. `SHA256SUMS.txt` verifies packaged bytes.

Raw/controlled-access data, large reference tracks, model checkpoints,
TensorBoard events, smoke-test outputs, and transient logs are intentionally
excluded. They belong in their governed source repositories or code release,
not in a journal data supplement.
